/* This file is auto generated, version 24~18.04.1-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#24~18.04.1-Ubuntu SMP Mon Jul 29 16:12:28 UTC 2019"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lgw01-amd64-030"
#define LINUX_COMPILER "gcc version 7.4.0 (Ubuntu 7.4.0-1ubuntu1~18.04.1)"
