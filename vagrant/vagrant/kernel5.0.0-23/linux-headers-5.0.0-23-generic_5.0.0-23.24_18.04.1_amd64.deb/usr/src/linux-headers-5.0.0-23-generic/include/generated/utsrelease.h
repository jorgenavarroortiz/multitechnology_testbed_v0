#define UTS_RELEASE "5.0.0-23-generic"
#define UTS_UBUNTU_RELEASE_ABI 23
