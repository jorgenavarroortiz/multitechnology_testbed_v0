/* This file is auto generated, version 201905251732 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#201905251732 SMP Sat May 25 17:34:28 UTC 2019"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "kathleen"
#define LINUX_COMPILER "gcc version 8.3.0 (Ubuntu 8.3.0-13ubuntu1)"
