#ifndef LWIP_RTP_H
#define LWIP_RTP_H

#if LWIP_SOCKET && LWIP_IGMP
void rtp_init(void);
#endif /* LWIP_SOCKET && LWIP_IGMP */

#endif /* LWIP_RTP_H */
