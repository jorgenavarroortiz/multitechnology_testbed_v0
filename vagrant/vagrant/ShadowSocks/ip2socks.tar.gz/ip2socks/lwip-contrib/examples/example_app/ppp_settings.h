#ifdef _MSC_VER
#pragma warning (disable: 4242) /* PPP only: conversion from 'x' to 'y', possible loss of data */
#pragma warning (disable: 4244) /* PPP only: conversion from 'x' to 'y', possible loss of data (again?) */
#pragma warning (disable: 4310) /* PPP only: cast truncates constant value */
#pragma warning (disable: 4706) /* PPP only: assignment within conditional expression */
#endif /* MSC_VER  */
