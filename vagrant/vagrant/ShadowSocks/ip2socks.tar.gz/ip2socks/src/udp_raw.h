/**
 * based on lwip-contrib
 */
#ifndef LWIP_UDP_RAW_H
#define LWIP_UDP_RAW_H

void udp_raw_init(void);

#endif /* LWIP_UDP_RAW_H */
