#ifndef LWIP_SOCKET_UTIL_H
#define LWIP_SOCKET_UTIL_H

#ifdef __cplusplus
extern "C" {
#endif

int setnonblocking(int fd);

#ifdef __cplusplus
}
#endif

#endif //LWIP_SOCKET_UTIL_H
