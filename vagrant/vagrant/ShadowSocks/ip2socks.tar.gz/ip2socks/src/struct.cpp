#include "struct.h"

struct Conf *conf = static_cast<Conf *>(malloc(sizeof(Conf)));
