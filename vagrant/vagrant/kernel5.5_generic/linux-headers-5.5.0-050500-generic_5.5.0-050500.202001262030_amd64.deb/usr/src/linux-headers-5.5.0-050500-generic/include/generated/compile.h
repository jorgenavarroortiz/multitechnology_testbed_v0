/* This file is auto generated, version 202001262030 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202001262030 SMP Mon Jan 27 01:33:36 UTC 2020"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "tangerine"
#define LINUX_COMPILER "gcc version 9.2.1 20200123 (Ubuntu 9.2.1-25ubuntu1)"
