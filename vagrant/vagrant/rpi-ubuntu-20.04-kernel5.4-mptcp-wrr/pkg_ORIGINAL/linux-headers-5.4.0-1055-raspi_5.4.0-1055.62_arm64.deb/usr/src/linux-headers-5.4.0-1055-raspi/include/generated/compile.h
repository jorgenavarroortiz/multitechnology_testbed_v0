/* This file is auto generated, version 62 */
/* SMP PREEMPT */
#define UTS_MACHINE "aarch64"
#define UTS_VERSION "#62 SMP PREEMPT Sat Mar 26 16:30:51 UTC 2022"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "ubuntu"
#define LINUX_COMPILER "gcc version 9.4.0 (Ubuntu 9.4.0-1ubuntu1~20.04.1)"
